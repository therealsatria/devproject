#!/bin/bash

# Script untuk mengecek spesifikasi sistem, penggunaan memori, dan benchmark CPU
# Output disimpan dalam file HTML
# Didesain untuk dijalankan tanpa koneksi internet dengan performa optimal

# Fungsi untuk cek dependensi dengan cache
declare -A DEP_CACHE
check_dependency() {
  if [[ -z "${DEP_CACHE[$1]}" ]]; then
    if ! command -v "$1" &> /dev/null; then
      echo "Error: $1 tidak ditemukan. Silakan install dengan 'sudo apt install $2' (atau package manager lain)."
      exit 1
    fi
    DEP_CACHE[$1]=1
  fi
}

echo "Mulai proses analisa informasi sistem dan benchmark..."

# Cek dependensi wajib
echo "Memeriksa dependensi..."
check_dependency "free" "procps"
check_dependency "bc" "bc"
check_dependency "dd" "coreutils"
check_dependency "openssl" "openssl"
check_dependency "uname" "coreutils"
check_dependency "md5sum" "coreutils"
check_dependency "gzip" "gzip"
check_dependency "sort" "coreutils"
check_dependency "grep" "grep"
check_dependency "cmp" "diffutils"
check_dependency "dmesg" "util-linux"

# Variabel untuk menyimpan hasil
OUTPUT_HTML="system_info.html"
TIMESTAMP=$(date "+%Y-%m-%d %H:%M:%S")

echo "Mengumpulkan spesifikasi sistem..."

# 1. Kumpulkan spesifikasi sistem dengan efisiensi
HOSTNAME=$(< /proc/sys/kernel/hostname)
DISTRO=$(grep -m1 '^PRETTY_NAME=' /etc/os-release 2>/dev/null | cut -d'"' -f2 || echo "Tidak dapat mendeteksi distro")
KERNEL=$(uname -r)
# Jumlah paket terinstal
PACKAGES="Tidak dapat mendeteksi jumlah paket"
if command -v dpkg >/dev/null 2>&1; then
  PACKAGES=$(dpkg-query -l | wc -l)
elif command -v rpm >/dev/null 2>&1; then
  PACKAGES=$(rpm -qa --last | wc -l)
elif command -v pacman >/dev/null 2>&1; then
  PACKAGES=$(pacman -Q | wc -l)
fi
SHELL_NAME=${SHELL##*/} # Ambil nama shell tanpa path
SHELL_VERSION=$(bash --version 2>/dev/null | head -n1 || echo "Tidak terdeteksi")
DE=${DESKTOP_SESSION:-"Tidak terdeteksi"}
DE_VERSION="Tidak terdeteksi"
if [[ "$DE" == *"plasma"* ]]; then
  DE_VERSION=$(plasmashell --version 2>/dev/null | head -n1 || echo "Tidak terdeteksi")
fi
# Deteksi Window Manager dengan pendekatan ringan
WM="Tidak terdeteksi"
if command -v wmctrl >/dev/null 2>&1; then
  WM=$(wmctrl -m 2>/dev/null | grep -m1 "Name:" | cut -d' ' -f2 || echo "Tidak terdeteksi")
elif [[ -n $(ps -C mutter --no-headers) ]]; then
  WM="Mutter"
elif [[ -n $(ps -C kwin_x11,kwin_wayland --no-headers) ]]; then
  WM="KWin"
elif [[ -n $(ps -C xfwm4 --no-headers) ]]; then
  WM="Xfwm4"
fi
SESSION_TYPE=${XDG_SESSION_TYPE:-"Tidak terdeteksi"}
FLATPAK_VERSION=$(flatpak --version 2>/dev/null || echo "Flatpak tidak terinstal")
SNAP_VERSION=$(snap --version 2>/dev/null | head -n 1 || echo "Snap tidak terinstal")
APPIMAGE_VERSION=$(appimage --version 2>/dev/null || echo "AppImage tidak terinstal")

echo "Mengukur penggunaan memori idle..."

# 2. Ukur penggunaan memori idle (5 samples, setiap 2 detik) dengan parsing efisien
MEMORY_SAMPLES=()
for i in {1..5}; do
  read -r _ mem_used _ <<< "$(free -m | grep -m1 Mem:)"
  MEMORY_SAMPLES+=("$mem_used")
  sleep 2
done

# Hitung rata-rata memori dengan Bash
TOTAL_MEMORY=0
for mem in "${MEMORY_SAMPLES[@]}"; do
  ((TOTAL_MEMORY += mem))
done
AVG_MEMORY=$(echo "scale=2; $TOTAL_MEMORY / ${#MEMORY_SAMPLES[@]}" | bc -l)

echo "Menjalankan benchmark CPU..."

# 3. Benchmark CPU: Perhitungan Pi (Aproksimasi dengan arctan)
START_TIME=$(date +%s.%N)
PI=$(echo "scale=1000; 4*a(1)" | bc -l)
END_TIME=$(date +%s.%N)
PI_TIME_SEC=$(printf "%.1f" "$(echo "$END_TIME - $START_TIME" | bc -l)")
PI_TIME_MS=$(printf "%.1f" "$(echo "$PI_TIME_SEC * 1000" | bc -l)")

# 4. Benchmark CPU: Hashing Data Besar (1GB data zero)
START_TIME=$(date +%s.%N)
dd if=/dev/zero bs=1M count=1024 2>/dev/null | md5sum >/dev/null
END_TIME=$(date +%s.%N)
HASH_TIME_SEC=$(printf "%.1f" "$(echo "$END_TIME - $START_TIME" | bc -l)")
HASH_TIME_MS=$(printf "%.1f" "$(echo "$HASH_TIME_SEC * 1000" | bc -l)")

# 5. Benchmark CPU: Kompresi Data (100MB data acak)
dd if=/dev/urandom bs=1M count=100 of=temp_random.bin 2>/dev/null
START_TIME=$(date +%s.%N)
gzip -9 temp_random.bin
END_TIME=$(date +%s.%N)
COMP_TIME_SEC=$(printf "%.1f" "$(echo "$END_TIME - $START_TIME" | bc -l)")
COMP_TIME_MS=$(printf "%.1f" "$(echo "$COMP_TIME_SEC * 1000" | bc -l)")
rm -f temp_random.bin.gz temp_random.bin

# 6. Benchmark CPU: Sorting Data Besar (1 juta angka acak)
seq 1 1000000 | shuf > temp_sort.txt
START_TIME=$(date +%s.%N)
sort -n temp_sort.txt >/dev/null
END_TIME=$(date +%s.%N)
SORT_TIME_SEC=$(printf "%.1f" "$(echo "$END_TIME - $START_TIME" | bc -l)")
SORT_TIME_MS=$(printf "%.1f" "$(echo "$SORT_TIME_SEC * 1000" | bc -l)")
rm -f temp_sort.txt

# 7. Benchmark CPU: Pencarian Pola (grep pada 100MB teks acak)
dd if=/dev/urandom bs=1M count=100 | tr -dc 'a-zA-Z0-9\n' > temp_text.txt
START_TIME=$(date +%s.%N)
grep -E 'a[0-9]+b' temp_text.txt >/dev/null
END_TIME=$(date +%s.%N)
GREP_TIME_SEC=$(printf "%.1f" "$(echo "$END_TIME - $START_TIME" | bc -l)")
GREP_TIME_MS=$(printf "%.1f" "$(echo "$GREP_TIME_SEC * 1000" | bc -l)")
rm -f temp_text.txt

# 8. Benchmark CPU: Enkripsi dan Dekripsi (AES-256 pada file 50MB)
TEMP_FILE="temp_data.bin"
TEMP_ENC_FILE="temp_data.enc"
TEMP_DEC_FILE="temp_data.dec"
PASSWORD="benchmarkpass"

# Buat file 50MB data zero
dd if=/dev/zero of="$TEMP_FILE" bs=1M count=50 2>/dev/null

# Enkripsi
START_TIME=$(date +%s.%N)
openssl enc -aes-256-cbc -salt -in "$TEMP_FILE" -out "$TEMP_ENC_FILE" -pass pass:"$PASSWORD" 2>/dev/null
END_TIME=$(date +%s.%N)
ENC_TIME_SEC=$(printf "%.1f" "$(echo "$END_TIME - $START_TIME" | bc -l)")
ENC_TIME_MS=$(printf "%.1f" "$(echo "$ENC_TIME_SEC * 1000" | bc -l)")

# Dekripsi
START_TIME=$(date +%s.%N)
openssl enc -aes-256-cbc -d -salt -in "$TEMP_ENC_FILE" -out "$TEMP_DEC_FILE" -pass pass:"$PASSWORD" 2>/dev/null
END_TIME=$(date +%s.%N)
DEC_TIME_SEC=$(printf "%.1f" "$(echo "$END_TIME - $START_TIME" | bc -l)")
DEC_TIME_MS=$(printf "%.1f" "$(echo "$DEC_TIME_SEC * 1000" | bc -l)")

echo "Menjalankan tes kestabilan sistem..."

# Tes Kestabilan 1: Enkripsi/Dekripsi dengan Verifikasi Integritas
ENCRYPT_STAB_FILE="stab_enc_data.bin"
ENCRYPT_ENC_FILE="stab_enc_enc.bin"
ENCRYPT_DEC_FILE="stab_enc_dec.bin"
ENCRYPT_PASSWORD="stabtest"
dd if=/dev/zero bs=1M count=1 > $ENCRYPT_STAB_FILE  # Data fixed 1MB
ENCRYPT_SUCCESS=0
for ((i=1; i<=50; i++)); do
  openssl enc -aes-256-cbc -salt -in $ENCRYPT_STAB_FILE -out $ENCRYPT_ENC_FILE -pass pass:$ENCRYPT_PASSWORD -pbkdf2 2>/dev/null
  openssl enc -aes-256-cbc -d -salt -in $ENCRYPT_ENC_FILE -out $ENCRYPT_DEC_FILE -pass pass:$ENCRYPT_PASSWORD -pbkdf2 2>/dev/null
  if cmp -s $ENCRYPT_STAB_FILE $ENCRYPT_DEC_FILE; then
    ((ENCRYPT_SUCCESS++))
  fi
done
ENCRYPT_STAB_RATE=$((ENCRYPT_SUCCESS * 2))
rm -f $ENCRYPT_STAB_FILE $ENCRYPT_ENC_FILE $ENCRYPT_DEC_FILE

# Tes Kestabilan 2: Hashing Berulang dengan Verifikasi Konsistensi
HASH_STAB_FILE="stab_hash.bin"
dd if=/dev/zero bs=1M count=1 > $HASH_STAB_FILE  # Data fixed 1MB
HASH_FIRST=$(md5sum $HASH_STAB_FILE | cut -d' ' -f1)
HASH_SUCCESS=0
for ((i=1; i<=50; i++)); do
  HASH=$(md5sum $HASH_STAB_FILE | cut -d' ' -f1)
  if [[ $HASH == $HASH_FIRST ]]; then
    ((HASH_SUCCESS++))
  fi
done
HASH_STAB_RATE=$((HASH_SUCCESS * 2))
rm -f $HASH_STAB_FILE

# Tes Kestabilan 3: Aritmatika Presisi Tinggi dengan Check Sum (Pi verifikasi)
EXPECTED_PI_PREFIX="3.1415926535"  # 10 digit awal Pi
PI_SUCCESS=0
for ((i=1; i<=50; i++)); do
  PI_VAL=$(echo "scale=1000; 16*a(1/5) - 4*a(1/239)" | bc -l | head -c 12)
  if [[ $PI_VAL == $EXPECTED_PI_PREFIX* ]]; then
    ((PI_SUCCESS++))
  fi
done
PI_STAB_RATE=$((PI_SUCCESS * 2))

# Tes Kestabilan 4: Stres Test Loop dengan Error Log Check
for ((i=1; i<=1000000; i++)); do ((SUM += i * i)); done  # Loop berat
STRES_ERRORS=$(dmesg | tail -n 10 | grep -i "error\|panic\|fault" || echo "No errors")
if [[ $STRES_ERRORS == "No errors" ]]; then
  STRES_STAB="Tinggi (tidak ada error)"
else
  STRES_STAB="Error terdeteksi"
fi

# Tes Kestabilan 5: I/O + CPU dengan Checksum Verifikasi
IO_STAB_FILE="stab_io.txt"
IO_SORTED="stab_io_sorted.txt"
IO_GREPPED="stab_io_grepped.txt"
seq 1 1000000 > $IO_STAB_FILE  # Data fixed
IO_FIRST_CHECKSUM=$(md5sum $IO_STAB_FILE | cut -d' ' -f1)
sort -n $IO_STAB_FILE > $IO_SORTED
grep "[0-9]" $IO_SORTED > $IO_GREPPED
IO_FINAL_CHECKSUM=$(md5sum $IO_GREPPED | cut -d' ' -f1)
if [[ $IO_FIRST_CHECKSUM == $IO_FINAL_CHECKSUM ]]; then
  IO_STAB="Tinggi (checksum match)"
else
  IO_STAB="Mismatch (data corrupted)"
fi
rm -f $IO_STAB_FILE $IO_SORTED $IO_GREPPED

echo "Proses analisa selesai. Menampilkan hasil di terminal:"

# Tampilkan hasil di terminal dalam format rapi
echo "=============================================="
echo "Linux OS Analyzer - Informasi Sistem"
echo "Dihasilkan pada: $TIMESTAMP"
echo "=============================================="
printf "%-40s : %s\n" "Nama Host" "$HOSTNAME"
printf "%-40s : %s\n" "Nama Distribusi" "$DISTRO"
printf "%-40s : %s\n" "Versi Kernel" "$KERNEL"
printf "%-40s : %s\n" "Jumlah Paket Terinstal" "$PACKAGES"
printf "%-40s : %s (%s)\n" "Shell Default" "$SHELL_NAME" "$SHELL_VERSION"
printf "%-40s : %s (%s)\n" "Desktop Environment" "$DE" "$DE_VERSION"
printf "%-40s : %s\n" "Window Manager" "$WM"
printf "%-40s : %s\n" "Tipe Sesi (Wayland/Xorg)" "$SESSION_TYPE"
printf "%-40s : %s\n" "Versi Flatpak" "$FLATPAK_VERSION"
printf "%-40s : %s\n" "Versi Snap" "$SNAP_VERSION"
printf "%-40s : %s\n" "Versi AppImage" "$APPIMAGE_VERSION"
printf "%-40s : %s MB\n" "Rata-rata Penggunaan Memori (Idle, 10 detik)" "$AVG_MEMORY"
echo "=============================================="
echo "Benchmark (lebih rendah lebih baik)"
echo "=============================================="
printf "%-60s : %s detik (%s ms)\n" "Benchmark CPU: Perhitungan Pi (1000 scale)" "$PI_TIME_SEC" "$PI_TIME_MS"
printf "%-60s : %s detik (%s ms)\n" "Benchmark CPU: Hashing Data Besar (1GB)" "$HASH_TIME_SEC" "$HASH_TIME_MS"
printf "%-60s : %s detik (%s ms)\n" "Benchmark CPU: Kompresi Data (100MB)" "$COMP_TIME_SEC" "$COMP_TIME_MS"
printf "%-60s : %s detik (%s ms)\n" "Benchmark CPU: Sorting Data Besar (1M angka)" "$SORT_TIME_SEC" "$SORT_TIME_MS"
printf "%-60s : %s detik (%s ms)\n" "Benchmark CPU: Pencarian Pola (100MB teks)" "$GREP_TIME_SEC" "$GREP_TIME_MS"
printf "%-60s : %s detik (%s ms)\n" "Benchmark CPU: Enkripsi AES-256 (50MB)" "$ENC_TIME_SEC" "$ENC_TIME_MS"
printf "%-60s : %s detik (%s ms)\n" "Benchmark CPU: Dekripsi AES-256 (50MB)" "$DEC_TIME_SEC" "$DEC_TIME_MS"
echo "=============================================="
echo "Tes Kestabilan Sistem (lebih tinggi lebih baik)"
echo "=============================================="
printf "%-60s : %s%% (stabil)\n" "Tes Kestabilan: Enkripsi/Dekripsi Verifikasi" "$ENCRYPT_STAB_RATE"
printf "%-60s : %s%% (stabil)\n" "Tes Kestabilan: Hashing Konsistensi" "$HASH_STAB_RATE"
printf "%-60s : %s%% (stabil)\n" "Tes Kestabilan: Aritmatika Pi Verifikasi" "$PI_STAB_RATE"
printf "%-60s : %s\n" "Tes Kestabilan: Stres Loop Error Log" "$STRES_STAB"
printf "%-60s : %s\n" "Tes Kestabilan: I/O + CPU Checksum" "$IO_STAB"
echo "=============================================="
echo "Credit: by: Satria Compute Channel"
echo "=============================================="

echo "Menulis hasil ke file HTML..."

# 6. Buat file HTML dengan tampilan menarik dan terpusat
cat << EOF > "$OUTPUT_HTML"
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Linux OS Analyzer</title>
  <style>
    body {
      font-family: 'Arial', sans-serif;
      margin: 0;
      padding: 20px;
      background: linear-gradient(135deg, #f0f4f8, #d9e2ec);
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
    }
    h1 {
      color: #2c3e50;
      text-align: center;
      text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.1);
    }
    table {
      width: 80%;
      max-width: 800px;
      border-collapse: collapse;
      background: #ffffff;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      margin: 20px auto;
    }
    th, td {
      padding: 12px;
      border: 1px solid #ddd;
      text-align: left;
    }
    th {
      background: linear-gradient(90deg, #3498db, #2980b9);
      color: #ffffff;
      text-align: center;
    }
    tr:nth-child(even) {
      background-color: #f9f9f9;
    }
    tr:hover {
      background-color: #f1f1f1;
    }
    p {
      color: #7f8c8d;
      text-align: center;
      font-style: italic;
    }
    .credit {
      text-align: center;
      font-size: 1.2em;
      color: #000000;
      margin-top: 10px;
    }
  </style>
</head>
<body>
  <div>
    <h1>Linux OS Analyzer</h1>
    <p>Dihasilkan pada: $TIMESTAMP</p>
    <table>
      <tr><th>Parameter</th><th>Nilai</th></tr>
      <tr><td>Nama Host</td><td>$HOSTNAME</td></tr>
      <tr><td>Nama Distribusi</td><td>$DISTRO</td></tr>
      <tr><td>Versi Kernel</td><td>$KERNEL</td></tr>
      <tr><td>Jumlah Paket Terinstal</td><td>$PACKAGES</td></tr>
      <tr><td>Shell Default</td><td>$SHELL_NAME ($SHELL_VERSION)</td></tr>
      <tr><td>Desktop Environment</td><td>$DE ($DE_VERSION)</td></tr>
      <tr><td>Window Manager</td><td>$WM</td></tr>
      <tr><td>Tipe Sesi (Wayland/Xorg)</td><td>$SESSION_TYPE</td></tr>
      <tr><td>Versi Flatpak</td><td>$FLATPAK_VERSION</td></tr>
      <tr><td>Versi Snap</td><td>$SNAP_VERSION</td></tr>
      <tr><td>Versi AppImage</td><td>$APPIMAGE_VERSION</td></tr>
      <tr><td>Rata-rata Penggunaan Memori (Idle, 10 detik)</td><td>$AVG_MEMORY MB</td></tr>
      <tr><th colspan="2">Benchmark (lebih rendah lebih baik)</th></tr>
      <tr><td>Benchmark CPU: Perhitungan Pi (1000 scale)</td><td>$PI_TIME_SEC detik ($PI_TIME_MS ms)</td></tr>
      <tr><td>Benchmark CPU: Hashing Data Besar (1GB)</td><td>$HASH_TIME_SEC detik ($HASH_TIME_MS ms)</td></tr>
      <tr><td>Benchmark CPU: Kompresi Data (100MB)</td><td>$COMP_TIME_SEC detik ($COMP_TIME_MS ms)</td></tr>
      <tr><td>Benchmark CPU: Sorting Data Besar (1M angka)</td><td>$SORT_TIME_SEC detik ($SORT_TIME_MS ms)</td></tr>
      <tr><td>Benchmark CPU: Pencarian Pola (100MB teks)</td><td>$GREP_TIME_SEC detik ($GREP_TIME_MS ms)</td></tr>
      <tr><td>Benchmark CPU: Enkripsi AES-256 (50MB)</td><td>$ENC_TIME_SEC detik ($ENC_TIME_MS ms)</td></tr>
      <tr><td>Benchmark CPU: Dekripsi AES-256 (50MB)</td><td>$DEC_TIME_SEC detik ($DEC_TIME_MS ms)</td></tr>
      <tr><th colspan="2">Tes Kestabilan Sistem (lebih tinggi lebih baik)</th></tr>
      <tr><td>Tes Kestabilan: Enkripsi/Dekripsi Verifikasi</td><td>$ENCRYPT_STAB_RATE% (stabil)</td></tr>
      <tr><td>Tes Kestabilan: Hashing Konsistensi</td><td>$HASH_STAB_RATE% (stabil)</td></tr>
      <tr><td>Tes Kestabilan: Aritmatika Pi Verifikasi</td><td>$PI_STAB_RATE% (stabil)</td></tr>
      <tr><td>Tes Kestabilan: Stres Loop Error Log</td><td>$STRES_STAB</td></tr>
      <tr><td>Tes Kestabilan: I/O + CPU Checksum</td><td>$IO_STAB</td></tr>
    </table>
    <p class="credit">by: Satria Compute Channel</p>
  </div>
</body>
</html>
EOF

# Bersihkan file sementara
rm -f "$TEMP_FILE" "$TEMP_ENC_FILE" "$TEMP_DEC_FILE"

# Pesan sukses
echo "Informasi sistem telah disimpan ke $OUTPUT_HTML oleh Linux OS Analyzer. Buka file tersebut di browser Anda."